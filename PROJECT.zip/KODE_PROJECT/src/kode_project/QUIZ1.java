/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package kode_project;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author riand
 */
public class QUIZ1 extends javax.swing.JFrame {

    /**
     * Creates new form QUIZ
     */
    public String questionId = "1";
    public String answer;
    public int sec = 0;
    public int min = 0;
    public int marks = 0;
    public int IdQuiz = 0;
    public int absen_siswa = 1;
    public String jumlah_soal;
    Timer time;

    public void answerCheck() {
        String studentAns = "";
        if (ans1.isSelected()) {
            studentAns = ans1.getText();
        } else if (ans2.isSelected()) {
            studentAns = ans2.getText();
        } else if (ans3.isSelected()) {
            studentAns = ans3.getText();
        } else if (ans4.isSelected()) {
            studentAns = ans4.getText();
        }
        if (studentAns.equals(answer)) {
            marks = marks + 1;
            String marks1 = String.valueOf(marks);
            marksLB.setText(marks1);
        }

        int questionID1 = Integer.parseInt(questionId);
        questionID1 = questionID1 + 1;
        questionId = String.valueOf(questionID1);
        numberLB.setText(questionId);

        if (questionId.equals(jumlah_soal)) {
            nextBT.setEnabled(false);
        }

        ans1.setSelected(false);
        ans2.setSelected(false);
        ans3.setSelected(false);
        ans4.setSelected(false);
    }

    public void question() {
        

        try {
            String sql = "SELECT * FROM question WHERE QuizID= '" + IdQuiz + "' AND  nomor_soal='" + questionId + "'";
            java.sql.Connection conn = (java.sql.Connection) koneksi.koneksiDB();
            PreparedStatement psmt = conn.prepareStatement(sql);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                questionLB.setText(rs.getString("Question"));
                ans1.setText(rs.getString("OptionA"));
                ans2.setText(rs.getString("OptionB"));
                ans3.setText(rs.getString("OptionC"));
                ans4.setText(rs.getString("OptionD"));
                answer = rs.getString("CorrectAnswer");
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
    }

    // In the submit() method of your other class
 public void submit() {
    try {
        // Parse input values from text fields
        int code = Integer.parseInt(kuisid.getText());
        String nama = namaLB.getText();
        int absen = Integer.parseInt(absenLB.getText());
        int mark = Integer.parseInt(marksLB.getText());

        // Get database connection
        java.sql.Connection conn = koneksi.koneksiDB();

        // Define SQL query with placeholders for PreparedStatement
        String sql = "INSERT INTO quiz_result(QuizID, nama, absen, mark) VALUES (?, ?, ?, ?)";

        // Create PreparedStatement
        PreparedStatement pstmt = conn.prepareStatement(sql);

        // Set parameter values for PreparedStatement
        pstmt.setInt(1, code);
        pstmt.setString(2, nama);
        pstmt.setInt(3, absen);
        pstmt.setInt(4, mark);

        // Execute the query to insert data
        pstmt.executeUpdate();

        // Close PreparedStatement and database connection
        pstmt.close();

        // If the data insertion is successful, close this frame and show the user dashboard
        this.dispose();
        try {
            Statement st = (Statement) conn.createStatement();
            st.executeUpdate("UPDATE user SET marks = '" + marks + "' WHERE absen = '" + absen_siswa + "' ");
            this.dispose();
            new homepage(absen_siswa).setVisible(true);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

    } catch (NumberFormatException e) {
        // Handle NumberFormatException
        JOptionPane.showMessageDialog(this, "Please enter valid numeric values for QuizID, Absen, and Mark.");
    } catch (SQLException e) {
        // Handle SQLException
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        e.printStackTrace();
    } catch (Exception e) {
        // Handle other exceptions
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        e.printStackTrace();
    }
}





    public QUIZ1(String code, int absen_siswa1) {
        initComponents();
    }

    public QUIZ1(int QuizID, int absen) {
        IdQuiz = QuizID;
        absen_siswa = absen;
        initComponents();
        numberLB.setText(questionId);
        try {
            String sql = "SELECT * FROM user WHERE absen= ? ";
            java.sql.Connection conn = (java.sql.Connection) koneksi.koneksiDB();
            PreparedStatement psmt = conn.prepareStatement(sql);
            psmt.setInt(1,absen_siswa);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                namaLB.setText(rs.getString("nama"));
                absenLB.setText(rs.getString("absen"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

        try {
            String sql = "SELECT * FROM question WHERE QuizID = '" + IdQuiz + "' AND  nomor_soal='" + questionId + "'";
            java.sql.Connection conn = (java.sql.Connection) koneksi.koneksiDB();
            PreparedStatement psmt = conn.prepareStatement(sql);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                questionLB.setText(rs.getString("Question"));
                ans1.setText(rs.getString("OptionA"));
                ans2.setText(rs.getString("OptionB"));
                ans3.setText(rs.getString("OptionC"));
                ans4.setText(rs.getString("OptionD"));
                answer = rs.getString("CorrectAnswer");
                kuisid.setText (rs.getString("QuizID"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }

        try {
            String sql = "SELECT COUNT(*) AS total_soal FROM question WHERE QuizID = '" + IdQuiz + "'";
            java.sql.Connection conn = (java.sql.Connection) koneksi.koneksiDB();
            PreparedStatement psmt = conn.prepareStatement(sql);
            ResultSet rs = psmt.executeQuery();
            while (rs.next()) {
                jumlah_soal = rs.getString("total_soal");
                QuizTotal.setText(jumlah_soal);
            }
            if (questionId.equals(jumlah_soal)) {
                nextBT.setEnabled(false);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e);
        }
        //time
        setLocationRelativeTo(this);
        time = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DetikLB.setText(String.valueOf(sec));
                MenitLB.setText(String.valueOf(min));
                if (sec == 60) {
                    sec = 0;
                    min++;
                    if (min == 10) {
                        time.stop();
                        answerCheck();
                        submit();
                    }
                }
                sec++;
            }
        });
        time.start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Answer = new javax.swing.ButtonGroup();
        namaLB = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        numberLB = new javax.swing.JLabel();
        marksLB = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        QuizTotal = new javax.swing.JLabel();
        kuisid = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        questionLB = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        ans1 = new javax.swing.JRadioButton();
        ans2 = new javax.swing.JRadioButton();
        ans3 = new javax.swing.JRadioButton();
        ans4 = new javax.swing.JRadioButton();
        nextBT = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        MenitLB = new javax.swing.JLabel();
        DetikLB = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        absenLB = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        namaLB.setBackground(new java.awt.Color(0, 0, 0));
        namaLB.setFont(new java.awt.Font("Berlin Sans FB", 1, 36)); // NOI18N
        namaLB.setText("NICKNAME");

        jPanel1.setBackground(new java.awt.Color(255, 153, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255)));
        jPanel1.setForeground(new java.awt.Color(102, 102, 255));
        jPanel1.setToolTipText("");

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("QUIZ NUMBER:");

        jLabel7.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("YOUR MARK:");

        numberLB.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        numberLB.setForeground(new java.awt.Color(255, 255, 255));
        numberLB.setText("0");

        marksLB.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        marksLB.setForeground(new java.awt.Color(255, 255, 255));
        marksLB.setText("0");

        jLabel8.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("QUIZ TOTAL:");

        QuizTotal.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        QuizTotal.setForeground(new java.awt.Color(255, 255, 255));
        QuizTotal.setText("0");

        kuisid.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        kuisid.setForeground(new java.awt.Color(255, 255, 255));
        kuisid.setText("0");

        jLabel11.setFont(new java.awt.Font("Berlin Sans FB", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("QUIZ ID:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(jLabel7)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(marksLB))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel8))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(QuizTotal)
                                .addComponent(numberLB))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(kuisid)))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(QuizTotal))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8)))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(numberLB))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(marksLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(kuisid)
                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 153, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(255, 255, 255), new java.awt.Color(255, 255, 255)));

        questionLB.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        questionLB.setForeground(new java.awt.Color(255, 255, 255));
        questionLB.setText("LOREM IPSUM DOLOR SIT AMET LOREM IPSUM DOLOR SIT AMET");
        questionLB.setVerticalAlignment(javax.swing.SwingConstants.TOP);

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Answer");

        ans1.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        ans1.setForeground(new java.awt.Color(255, 255, 255));
        ans1.setText("A");
        ans1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans1ActionPerformed(evt);
            }
        });

        ans2.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        ans2.setForeground(new java.awt.Color(255, 255, 255));
        ans2.setText("B");
        ans2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans2ActionPerformed(evt);
            }
        });

        ans3.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        ans3.setForeground(new java.awt.Color(255, 255, 255));
        ans3.setText("C");
        ans3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans3ActionPerformed(evt);
            }
        });

        ans4.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        ans4.setForeground(new java.awt.Color(255, 255, 255));
        ans4.setText("D");
        ans4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ans4ActionPerformed(evt);
            }
        });

        nextBT.setBackground(new java.awt.Color(255, 102, 0));
        nextBT.setFont(new java.awt.Font("Berlin Sans FB", 0, 18)); // NOI18N
        nextBT.setForeground(new java.awt.Color(255, 255, 255));
        nextBT.setText("Next");
        nextBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextBTActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 102, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Submit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ans1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(ans2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ans3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(questionLB, javax.swing.GroupLayout.DEFAULT_SIZE, 716, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(ans4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(104, 104, 104))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(nextBT, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(questionLB, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel4)
                .addGap(26, 26, 26)
                .addComponent(ans1)
                .addGap(26, 26, 26)
                .addComponent(ans2)
                .addGap(26, 26, 26)
                .addComponent(ans3)
                .addGap(26, 26, 26)
                .addComponent(ans4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nextBT, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB", 1, 24)); // NOI18N
        jLabel3.setText("10MIN");

        jLabel5.setFont(new java.awt.Font("Berlin Sans FB", 1, 24)); // NOI18N
        jLabel5.setText("TIME LIMIT :");

        jLabel6.setFont(new java.awt.Font("Berlin Sans FB", 1, 24)); // NOI18N
        jLabel6.setText("TIME TAKEN :");

        MenitLB.setFont(new java.awt.Font("VALORANT", 1, 24)); // NOI18N
        MenitLB.setText("00");

        DetikLB.setFont(new java.awt.Font("VALORANT", 1, 24)); // NOI18N
        DetikLB.setText("00");

        jLabel9.setFont(new java.awt.Font("Berlin Sans FB", 0, 36)); // NOI18N
        jLabel9.setText("ABSEN :");

        absenLB.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 36)); // NOI18N
        absenLB.setText("0");

        jPanel3.setBackground(new java.awt.Color(255, 102, 51));

        jLabel10.setFont(new java.awt.Font("Berlin Sans FB Demi", 0, 48)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("KODE QUIZY");

        jButton4.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 102, 51));
        jButton4.setText("LOGOUT");
        jButton4.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 525, Short.MAX_VALUE)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(absenLB))
                            .addComponent(namaLB))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(MenitLB)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(DetikLB)))
                        .addGap(67, 67, 67))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(38, 38, 38))))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(namaLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(absenLB)
                    .addComponent(jLabel6)
                    .addComponent(MenitLB)
                    .addComponent(DetikLB))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 656, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nextBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextBTActionPerformed

        answerCheck();
        question();
    }//GEN-LAST:event_nextBTActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int a = JOptionPane.showConfirmDialog(null, "Yakin?", "Select", JOptionPane.YES_NO_OPTION);
        if (a == 0) {
            answerCheck();
            submit();
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void ans1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans1ActionPerformed
        if (ans1.isSelected()) {
            ans2.setSelected(false);
            ans3.setSelected(false);
            ans4.setSelected(false);
        }
    }//GEN-LAST:event_ans1ActionPerformed

    private void ans2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans2ActionPerformed
        if (ans2.isSelected()) {
            ans1.setSelected(false);
            ans3.setSelected(false);
            ans4.setSelected(false);
        }
    }//GEN-LAST:event_ans2ActionPerformed

    private void ans3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans3ActionPerformed
        if (ans3.isSelected()) {
            ans1.setSelected(false);
            ans2.setSelected(false);
            ans4.setSelected(false);
        }
    }//GEN-LAST:event_ans3ActionPerformed

    private void ans4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ans4ActionPerformed
        if (ans4.isSelected()) {
            ans2.setSelected(false);
            ans3.setSelected(false);
            ans1.setSelected(false);
        }
    }//GEN-LAST:event_ans4ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        System.exit(0);// TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QUIZ1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QUIZ1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QUIZ1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QUIZ1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QUIZ1(901,1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup Answer;
    private javax.swing.JLabel DetikLB;
    private javax.swing.JLabel MenitLB;
    private javax.swing.JLabel QuizTotal;
    private javax.swing.JLabel absenLB;
    private javax.swing.JRadioButton ans1;
    private javax.swing.JRadioButton ans2;
    private javax.swing.JRadioButton ans3;
    private javax.swing.JRadioButton ans4;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel kuisid;
    private javax.swing.JLabel marksLB;
    private javax.swing.JLabel namaLB;
    private javax.swing.JButton nextBT;
    private javax.swing.JLabel numberLB;
    private javax.swing.JLabel questionLB;
    // End of variables declaration//GEN-END:variables
}
